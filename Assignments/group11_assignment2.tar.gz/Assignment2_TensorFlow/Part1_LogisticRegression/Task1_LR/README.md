# Task 1: Logistic Regression using Tensorflow

Logistic Regression model is implemented using Tensorflow backend.

## Usage

To execute the program, navigate to the directory with the python scripts, and follow the syntax below:

```bash
$ sudo bash run.sh
```
